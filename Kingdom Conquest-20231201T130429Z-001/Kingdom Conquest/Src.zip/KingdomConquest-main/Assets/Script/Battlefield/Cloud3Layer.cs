using UnityEngine;
using System.Collections;

public class Cloud3Layer : MonoBehaviour {
	
	public GameObject cloud1 = null;
	public GameObject cloud2 = null;
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
