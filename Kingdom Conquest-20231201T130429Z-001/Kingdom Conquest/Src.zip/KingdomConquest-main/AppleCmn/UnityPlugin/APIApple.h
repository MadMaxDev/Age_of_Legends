//
//  APIApple.h
//  Unity-iPhone
//
//  Created by weihua on 12-12-5.
//
//

#import <Foundation/Foundation.h>

@interface APIApple : NSObject

@end
